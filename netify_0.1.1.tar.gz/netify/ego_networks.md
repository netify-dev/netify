---
title: "Ego Networks: Understanding Local Network Structures"
author: "Cassy Dorff and Shahryar Minhas"
date: "2025-06-28"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{Ego Networks: Understanding Local Network Structures}
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteEncoding{UTF-8}
---



This vignette demonstrates how to analyze ego networks using `netify`. Ego networks focus on the immediate social environment of individual actors, revealing how local structures shape global network phenomena. This approach is essential for understanding how individual actors navigate their social worlds and how local patterns aggregate into system-wide behaviors.

## Why Ego Networks Matter for Social Science

While full network analysis reveals system-wide patterns, ego networks help us understand:

- **Individual agency**: How do actors leverage their immediate connections?
- **Local structures**: What patterns emerge in actors' immediate neighborhoods?
- **Network inequality**: How do ego network characteristics vary across actors?
- **Strategic positioning**: How do actors build and maintain their local networks?
- **Diffusion mechanisms**: How do ideas, behaviors, or resources spread through local connections?

Ego networks bridge micro-level behavior and macro-level outcomes, making them crucial for:

* **International Relations**: Understanding how states manage their immediate diplomatic neighborhoods
* **Comparative Politics**: Analyzing how political parties build local coalition networks
* **Political Behavior**: Examining how individuals' social environments shape political attitudes
* **Policy Networks**: Tracking how organizations position themselves in governance networks

### What Are Ego Networks?

An ego network consists of:

1. **Ego**: The focal actor (node) under study
2. **Alters**: Actors directly connected to the ego
3. **Alter-alter ties**: Connections among the ego's alters
4. **Neighborhood boundary**: The threshold defining who counts as an alter


``` r
library(netify)
library(tidyverse)
library(patchwork)
```

## Building Ego Networks from International Relations Data

Let's start by examining how countries manage their diplomatic neighborhoods using ICEWS event data:


``` r
# Load ICEWS data
data(icews)

# Choose attributes for our analysis
nvars <- c("i_polity2", "i_log_gdp", "i_log_pop", "i_region")
dvars <- c("matlCoop", "verbConf", "matlConf")

# Create a comprehensive netify object
netlet <- netify(
    icews,
    actor1 = "i", actor2 = "j",
    time = "year",
    symmetric = FALSE, 
    weight = "verbCoop",
    mode = "unipartite", 
    sum_dyads = FALSE,
    actor_time_uniform = TRUE,
    diag_to_NA = TRUE, 
    missing_to_zero = TRUE,
    nodal_vars = nvars,
    dyad_vars = dvars
)

print(netlet)
```

This creates a longitudinal network of verbal cooperation between countries, with additional attributes capturing material cooperation, conflicts, and country characteristics.

## Creating and Analyzing Ego Networks

### Basic Ego Network Extraction

The `ego_netify()` function extracts ego networks with several key parameters:

- `ego`: The focal actor's name
- `threshold`: Minimum edge weight for inclusion (default: mean weight for weighted networks)
- `ngbd_direction`: For directed networks - "out", "in", or "any"
- `include_ego`: Whether to include the ego in the returned network

Let's examine Pakistan's diplomatic network:


``` r
# Extract Pakistan's ego network
pakistan_ego_net <- ego_netify(netlet, ego = "Pakistan")

print(pakistan_ego_net)
```

The output shows Pakistan has 81 unique alters across the time series. This relatively high number suggests Pakistan maintains broad diplomatic engagement despite regional challenges.

### Understanding Neighborhood Composition

We can determine all sorts of information about the neighborhood via the `summary` function: 


``` r
ngbd_summary <- summary(pakistan_ego_net)
head(ngbd_summary)
#>    net num_actors   density num_edges prop_edges_missing mean_edge_weight
#> 1 2002         35 0.7551020       925                  0        166.93445
#> 2 2003         30 0.8788889       791                  0        258.17356
#> 3 2004         51 0.7274125      1892                  0         95.28745
#> 4 2005         49 0.8167430      1961                  0        113.05315
#> 5 2006         41 0.8221297      1382                  0        139.35366
#> 6 2007         42 0.8707483      1536                  0        174.43148
#>   sd_edge_weight median_edge_weight min_edge_weight max_edge_weight
#> 1       514.1573                 14               0            6003
#> 2       660.1221                 39               0            5937
#> 3       351.0150                  9               0            5141
#> 4       410.7403                 14               0            6561
#> 5       490.6335                 18               0            7579
#> 6       550.6169                 25               0            7125
#>   competition_row competition_col sd_of_row_means sd_of_col_means
#> 1      0.08100030      0.07897426        229.4351        224.9583
#> 2      0.08397074      0.07807595        323.6456        304.2249
#> 3      0.06014889      0.05662972        138.3784        132.2361
#> 4      0.06493042      0.05954332        168.7123        158.1764
#> 5      0.07655516      0.06874899        206.3296        190.2663
#> 6      0.06715083      0.06141609        238.1953        221.8779
#>   covar_of_row_col_means reciprocity transitivity
#> 1              0.9926160   0.9790484    0.8489611
#> 2              0.9782197   0.9564141    0.9378381
#> 3              0.9885674   0.9734966    0.8351142
#> 4              0.9931345   0.9839155    0.8959472
#> 5              0.9871813   0.9790556    0.9023721
#> 6              0.9907272   0.9765549    0.9267179
```

Let's examine how Pakistan's ego network varies over time:


``` r
plot_graph_stats(ngbd_summary, specific_stats='num_actors')
```

![plot of chunk unnamed-chunk-5](figure/unnamed-chunk-5-1.png)

### Visualizing Ego Network Evolution


``` r
# Add centrality measures for visualization
pakistan_ego_net <- add_node_vars(
    pakistan_ego_net,
    summary_actor(pakistan_ego_net),
    "actor", "time"
)
```

# Default Ego Network Visualization

When visualizing ego networks, `netify` automatically applies optimized defaults that make the ego clearly visible while preserving the structure of alter-alter relationships. For ego networks, the package:

- Sets `remove_isolates = FALSE` by default to ensure the ego remains visible even when ego edges are removed
- Uses a hierarchical layout that places the ego at center with alters arranged by their network centrality
- Automatically highlights the ego node for easy identification
- Applies appropriate visual styling to emphasize network structure

The `netify` package provides several specialized ego network layouts:
- **hierarchical** (default): Arranges alters in concentric circles based on their centrality
- **radial**: Positions alters in rings based on their connection strength to the ego
- **ego_centric**: Creates a buffer zone around the ego with organic force-directed positioning
- **concentric**: Simple concentric circles for alters

Let's visualize Pakistan's ego network using the hierarchical layout:


``` r
# Simple default plot - netify automatically applies ego network optimizations
plot(pakistan_ego_net)
```

![plot of chunk unnamed-chunk-7](figure/unnamed-chunk-7-1.png)

For more control over the visualization, we can customize the layout and styling:


``` r
# Hierarchical layout based on centrality  
# This layout places Pakistan at center with buffer zones
pakistan_hierarchical_layout <- create_hierarchical_ego_layout(
    pakistan_ego_net,
    min_radius = 1.5,  # This is already the buffer radius!
    max_radius = 4.5,
    seed = 456
)

plot(remove_ego_edges(pakistan_ego_net),  # remove pakistan edges since we already know all of these are connected to apkistan
    point_layout = pakistan_hierarchical_layout,
    mutate_weight = log1p,
    edge_alpha_label = 'Log(Verb.\n Coop.)',
    edge_linewidth = 0.05,  # Very thin edges
    node_size_by = "strength_sum_total",
    node_size_label = "Total Strength",
    highlight = c("Pakistan",'China','United States'),
    highlight_colors = c("Pakistan" = "#4daf4a", 'China'='#e41a1c','United States'='#377eb8',"Other" = "grey40"),
    highlight_size_increase = c(2, 1, 1, 1),  # Pakistan 2x, China/US normal, others half size
    highlight_label = "",
    # node_alpha = 0.8,
    curve_edges = FALSE,
    remove_isolates = FALSE  # Don't remove any nodes!
) +
    labs(
        title = "Pakistan's Diplomatic Network - Hierarchical Layout",
        subtitle = "Distance from Pakistan (center) reflects node centrality"
    ) +
        theme(legend.position='right')
```

![plot of chunk unnamed-chunk-8](figure/unnamed-chunk-8-1.png)

Pakistan's ego network shows interesting temporal dynamics. The network appears to densify over time, with certain actors (sized by strength) becoming more prominent. Pakistan (highlighted) maintains a central position, but the changing composition of alters reflects shifting geopolitical alignments.

The hierarchical layout provides excellent clarity by:
- Placing Pakistan firmly at the center
- Arranging more central alters (those with many connections) closer to Pakistan
- Peripheral alters with fewer connections positioned farther away
- Making temporal changes in network structure visually apparent

## Comparing Ego Networks Across Actors

### Major Powers' Ego Networks

Let's compare how different types of powers structure their local networks:


``` r
# Extract ego networks for major powers
us_ego <- ego_netify(netlet, ego = "United States")
china_ego <- ego_netify(netlet, ego = "China")
russia_ego <- ego_netify(netlet, ego = "Russian Federation")

# Get summaries to track network sizes over time
us_summary <- summary(us_ego)
china_summary <- summary(china_ego)
russia_summary <- summary(russia_ego)

# Visualize network size evolution for major powers
# Combine summaries for comparison
major_powers_summary <- rbind(
    cbind(us_summary, country = "United States"),
    cbind(china_summary, country = "China"),
    cbind(russia_summary, country = "Russian Federation")
)

# Plot network sizes over time
ggplot(major_powers_summary, aes(x = net, y = num_actors, color = country, group = country)) +
    geom_line(linewidth = 1.2) +
    geom_point(size = 3) +
    labs(
        title = "Ego Network Sizes of Major Powers Over Time",
        x = "Year",
        y = "Number of Actors in Ego Network",
        color = "Country"
    ) +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
```

![plot of chunk unnamed-chunk-9](figure/unnamed-chunk-9-1.png)

### Structural Properties of Ego Networks


``` r
# Get summaries for each ego network
us_summary <- summary(us_ego)
china_summary <- summary(china_ego)
russia_summary <- summary(russia_ego)
pakistan_summary_stored <- summary(pakistan_ego_net)

# Alternative: Create a comparative panel plot
# Combine all summaries into one dataframe for comparison
combined_summary <- rbind(
    cbind(us_summary[, c("net", "density", "transitivity")], country = "United States"),
    cbind(china_summary[, c("net", "density", "transitivity")], country = "China"),
    cbind(russia_summary[, c("net", "density", "transitivity")], country = "Russia"),
    cbind(pakistan_summary_stored[, c("net", "density", "transitivity")], country = "Pakistan")
)

# Reshape for faceting
combined_long <- combined_summary %>%
    pivot_longer(cols = c("density", "transitivity"), 
                 names_to = "metric", 
                 values_to = "value")

# Create comparative plot
ggplot(combined_long, aes(x = net, y = value, color = country, group = country)) +
    geom_line(linewidth = 1.2) +
    geom_point(size = 2) +
    facet_wrap(
        ~metric, scales = "free_y", ncol = 2,
        labeller = labeller(metric = c(
            density = "Density", 
            transitivity = "Transitivity"))) +
    labs(x='',y='',color='') +
    scale_color_brewer(palette='Set1') +
    theme_stat_netify()
```

![plot of chunk unnamed-chunk-10](figure/unnamed-chunk-10-1.png)

What we see:

- The US maintains the highest density ego network, suggesting comprehensive engagement with its alters
- Pakistan shows high transitivity, indicating its partners tend to cooperate with each other
- China's lower density but moderate degree suggests selective but meaningful partnerships

## Advanced Ego Network Analysis

### Analyzing Ego Network Composition with Attributes

Do countries' ego networks show homophily? Let's test whether democracies cluster in ego networks:


``` r
# Test homophily in Pakistan's ego network
pakistan_homophily <- homophily(
    pakistan_ego_net,
    attribute = "i_polity2",
    method = "correlation"
)

print(pakistan_homophily)
#>     net    layer attribute      method threshold_value homophily_correlation
#> 1  2002 verbCoop i_polity2 correlation               0          -0.037128679
#> 2  2003 verbCoop i_polity2 correlation               0          -0.104984165
#> 3  2004 verbCoop i_polity2 correlation               0           0.023783460
#> 4  2005 verbCoop i_polity2 correlation               0           0.082451677
#> 5  2006 verbCoop i_polity2 correlation               0           0.139310220
#> 6  2007 verbCoop i_polity2 correlation               0           0.077125204
#> 7  2008 verbCoop i_polity2 correlation               0           0.034020025
#> 8  2009 verbCoop i_polity2 correlation               0           0.036429324
#> 9  2010 verbCoop i_polity2 correlation               0           0.118938537
#> 10 2011 verbCoop i_polity2 correlation               0           0.094096682
#> 11 2012 verbCoop i_polity2 correlation               0           0.073643500
#> 12 2013 verbCoop i_polity2 correlation               0           0.022306267
#> 13 2014 verbCoop i_polity2 correlation               0           0.005474008
#>    mean_similarity_connected mean_similarity_unconnected similarity_difference
#> 1                  -8.987654                   -8.406504            -0.5811503
#> 2                  -8.616519                   -6.487179            -2.1293397
#> 3                  -7.907143                   -8.260417             0.3532738
#> 4                  -8.041526                   -9.478947             1.4374210
#> 5                  -8.108239                  -10.631148             2.5229084
#> 6                  -8.050445                   -9.791045             1.7405997
#> 7                  -7.149474                   -7.849057             0.6995829
#> 8                  -8.456693                   -9.520000             1.0633071
#> 9                  -8.218440                  -10.893333             2.6748936
#> 10                 -7.826923                   -9.572650             1.7457265
#> 11                 -8.201711                   -9.648438             1.4467260
#> 12                 -8.670157                   -9.132075             0.4619184
#> 13                 -8.018576                   -8.142857             0.1242813
#>    p_value    ci_lower    ci_upper n_connected_pairs n_unconnected_pairs
#> 1    0.391 -0.11937366  0.04342514               405                 123
#> 2    0.038 -0.18423856 -0.01783183               339                  39
#> 3    0.397 -0.02969511  0.08222429               840                 288
#> 4    0.005  0.02867182  0.13898884               891                 190
#> 5    0.000  0.06871687  0.20940585               619                 122
#> 6    0.035  0.01385133  0.15040974               674                  67
#> 7    0.424 -0.03832611  0.09885648               475                  53
#> 8    0.466 -0.05275951  0.12713432               381                  25
#> 9    0.000  0.05258936  0.17986916               705                  75
#> 10   0.012  0.02410828  0.16656496               624                 117
#> 11   0.035  0.01268467  0.13353012               818                 128
#> 12   0.649 -0.05492240  0.10734894               382                  53
#> 13   0.919 -0.07609654  0.08975771               323                  28
#>    n_missing n_pairs
#> 1          2     595
#> 2          2     435
#> 3          3    1275
#> 4          2    1176
#> 5          2     820
#> 6          3     861
#> 7          2     595
#> 8          2     465
#> 9          1     820
#> 10         1     780
#> 11         2    1035
#> 12         1     465
#> 13         0     351

# Since this is longitudinal data, use temporal plot
plot_homophily(
    pakistan_homophily,
    type = "temporal"
) +
    labs(
        title = "Democratic Homophily in Pakistan's Ego Network Over Time",
        subtitle = "Evolution of regime type clustering in Pakistan's neighborhood"
    )
```

![plot of chunk unnamed-chunk-11](figure/unnamed-chunk-11-1.png)

What if we changed the threshold for defining the ego network? 


``` r
# Create a more restrictive ego network with higher threshold
pakistan_ego_net_strict <- ego_netify(netlet, ego = "Pakistan", threshold = 50)

# Test homophily in the stricter network
pakistan_homophily_strict <- homophily(
    pakistan_ego_net_strict,
    attribute = "i_polity2",
    method = "correlation"
)

print(pakistan_homophily_strict)
#>     net    layer attribute      method threshold_value homophily_correlation
#> 1  2002 verbCoop i_polity2 correlation               0          -0.010949454
#> 2  2003 verbCoop i_polity2 correlation               0           0.012408436
#> 3  2004 verbCoop i_polity2 correlation               0           0.084600682
#> 4  2005 verbCoop i_polity2 correlation               0           0.095123829
#> 5  2006 verbCoop i_polity2 correlation               0           0.067736879
#> 6  2007 verbCoop i_polity2 correlation               0           0.161398693
#> 7  2008 verbCoop i_polity2 correlation               0           0.092585189
#> 8  2009 verbCoop i_polity2 correlation               0           0.002502198
#> 9  2010 verbCoop i_polity2 correlation               0           0.025785399
#> 10 2011 verbCoop i_polity2 correlation               0          -0.065487292
#> 11 2012 verbCoop i_polity2 correlation               0          -0.049142713
#> 12 2013 verbCoop i_polity2 correlation               0           0.057502201
#> 13 2014 verbCoop i_polity2 correlation               0          -0.006293243
#>    mean_similarity_connected mean_similarity_unconnected similarity_difference
#> 1                  -8.786364                   -8.575758            -0.2106061
#> 2                  -7.282209                   -7.625000             0.3427914
#> 3                  -7.422535                   -9.170732             1.7481965
#> 4                  -8.192389                  -10.272727             2.0803383
#> 5                  -8.406040                  -10.074074             1.6680338
#> 6                  -8.311741                  -15.500000             7.1882591
#> 7                  -7.926667                  -12.666667             4.7400000
#> 8                  -7.826923                   -8.000000             0.1730769
#> 9                  -8.888889                  -10.000000             1.1111111
#> 10                 -9.375940                   -6.333333            -3.0426065
#> 11                 -8.542986                   -7.000000            -1.5429864
#> 12                 -8.762712                  -11.500000             2.7372881
#> 13                 -8.727273                   -8.500000            -0.2272727
#>    p_value    ci_lower   ci_upper n_connected_pairs n_unconnected_pairs
#> 1    0.855 -0.12557069 0.09743161               220                  33
#> 2    0.880 -0.08784225 0.11576047               163                   8
#> 3    0.129 -0.01813802 0.18567440               284                  41
#> 4    0.032  0.01282912 0.17431700               473                  55
#> 5    0.229 -0.04143049 0.17338157               298                  27
#> 6    0.004  0.02508329 0.27318689               247                   6
#> 7    0.302 -0.06510012 0.21785042               150                   3
#> 8    1.000 -0.02135338 0.02967049               104                   1
#> 9    0.839 -0.05960356 0.10016814               117                   3
#> 10   0.473 -0.17620899 0.04792910               133                   3
#> 11   0.486 -0.14120982 0.05797438               221                  10
#> 12   0.568 -0.07418698 0.20939489               118                   2
#> 13   0.974 -0.09565343 0.09367912               132                   4
#>    n_missing n_pairs
#> 1          1     276
#> 2          2     210
#> 3          3     406
#> 4          2     595
#> 5          1     351
#> 6          2     300
#> 7          1     171
#> 8          1     120
#> 9          1     136
#> 10         1     153
#> 11         1     253
#> 12         1     136
#> 13         0     136

# Since this is longitudinal data, use temporal plot
plot_homophily(
    pakistan_homophily_strict,
    type = "temporal"
) +
    labs(
        title = "Democratic Homophily in Pakistan's Ego Network Over Time (Threshold of 50)",
        subtitle = "Evolution of regime type clustering in Pakistan's neighborhood"
    )
```

![plot of chunk unnamed-chunk-12](figure/unnamed-chunk-12-1.png)

### Ego Networks Across Different Relationship Types

Let's examine how ego networks differ across cooperation and conflict:


``` r
# Create networks for different relationship types
conflict_net <- netify(
    icews,
    actor1 = "i", actor2 = "j",
    time = "year",
    symmetric = FALSE,
    weight = "verbConf",
    nodal_vars = nvars
)

# Extract Pakistan's conflict ego network
pakistan_conflict_ego <- ego_netify(conflict_net, ego = "Pakistan")

# Compare cooperation vs conflict neighborhoods
# Get unique alters in each network type
coop_alters <- unique(unlist(lapply(pakistan_ego_net, rownames)))
conf_alters <- unique(unlist(lapply(pakistan_conflict_ego, rownames)))

# Create Venn diagram data
venn_data <- data.frame(
    category = c("Cooperation Only", "Both", "Conflict Only"),
    count = c(
        length(setdiff(coop_alters, conf_alters)),
        length(intersect(coop_alters, conf_alters)),
        length(setdiff(conf_alters, coop_alters))
    )
)

ggplot(venn_data, aes(x = category, y = count, fill = category)) +
    geom_col() +
    scale_fill_manual(values = c("Cooperation Only" = "lightblue", 
                                 "Both" = "purple", 
                                 "Conflict Only" = "salmon")) +
    labs(
        title = "Pakistan's Cooperation vs Conflict Networks",
        subtitle = "Overlap between diplomatic partners and conflict relationships",
        x = "", y = "Number of Countries"
    ) +
    theme_minimal() +
    guides(fill = "none")
```

![plot of chunk unnamed-chunk-13](figure/unnamed-chunk-13-1.png)

### Using `compare_networks()` for Ego Network Evolution

Let's analyze how Pakistan's ego network changes over time:


``` r
# Compare Pakistan's ego network across time periods
pakistan_temporal_comp <- compare_networks(
    pakistan_ego_net,
    method = "all"
)

print(pakistan_temporal_comp)
#> Network Comparison Results
#> ==========================
#> Type: temporal 
#> Method: all 
#> Networks compared: 13 
#> 
#> Summary Statistics:
#>       metric         mean           sd          min          max
#>  correlation 8.244955e-01 6.429305e-02    0.6563597 9.492684e-01
#>      jaccard 5.496187e-01 1.000552e-01    0.3259804 8.728972e-01
#>      hamming 2.666039e-01 8.380574e-02    0.0555102 5.142857e-01
#>     spectral 1.059231e+04 3.871917e+03 4042.5677204 2.095161e+04
#> 
#> Edge Changes:
#>   2002_vs_2003: 12 added, 500 removed, 425 maintained
#>   2002_vs_2004: 23 added, 480 removed, 445 maintained
#>   2002_vs_2005: 43 added, 308 removed, 617 maintained
#>   2002_vs_2006: 41 added, 411 removed, 514 maintained
#>   2002_vs_2007: 49 added, 315 removed, 610 maintained
#>   2002_vs_2008: 27 added, 478 removed, 447 maintained
#>   2002_vs_2009: 40 added, 437 removed, 488 maintained
#>   2002_vs_2010: 42 added, 355 removed, 570 maintained
#>   2002_vs_2011: 28 added, 398 removed, 527 maintained
#>   2002_vs_2012: 46 added, 368 removed, 557 maintained
#>   2002_vs_2013: 32 added, 534 removed, 391 maintained
#>   2002_vs_2014: 11 added, 619 removed, 306 maintained
#>   2003_vs_2004: 105 added, 74 removed, 363 maintained
#>   2003_vs_2005: 261 added, 38 removed, 399 maintained
#>   2003_vs_2006: 254 added, 136 removed, 301 maintained
#>   2003_vs_2007: 259 added, 37 removed, 400 maintained
#>   2003_vs_2008: 112 added, 75 removed, 362 maintained
#>   2003_vs_2009: 161 added, 70 removed, 367 maintained
#>   2003_vs_2010: 275 added, 100 removed, 337 maintained
#>   2003_vs_2011: 160 added, 42 removed, 395 maintained
#>   2003_vs_2012: 272 added, 106 removed, 331 maintained
#>   2003_vs_2013: 186 added, 200 removed, 237 maintained
#>   2003_vs_2014: 58 added, 178 removed, 259 maintained
#>   2004_vs_2005: 261 added, 69 removed, 399 maintained
#>   2004_vs_2006: 196 added, 109 removed, 359 maintained
#>   2004_vs_2007: 264 added, 73 removed, 395 maintained
#>   2004_vs_2008: 87 added, 81 removed, 387 maintained
#>   2004_vs_2009: 140 added, 80 removed, 388 maintained
#>   2004_vs_2010: 255 added, 111 removed, 357 maintained
#>   2004_vs_2011: 164 added, 77 removed, 391 maintained
#>   2004_vs_2012: 210 added, 75 removed, 393 maintained
#>   2004_vs_2013: 128 added, 173 removed, 295 maintained
#>   2004_vs_2014: 32 added, 183 removed, 285 maintained
#>   2005_vs_2006: 73 added, 178 removed, 482 maintained
#>   2005_vs_2007: 143 added, 144 removed, 516 maintained
#>   2005_vs_2008: 43 added, 229 removed, 431 maintained
#>   2005_vs_2009: 48 added, 180 removed, 480 maintained
#>   2005_vs_2010: 131 added, 179 removed, 481 maintained
#>   2005_vs_2011: 114 added, 219 removed, 441 maintained
#>   2005_vs_2012: 135 added, 192 removed, 468 maintained
#>   2005_vs_2013: 123 added, 360 removed, 300 maintained
#>   2005_vs_2014: 55 added, 398 removed, 262 maintained
#>   2006_vs_2007: 213 added, 109 removed, 446 maintained
#>   2006_vs_2008: 75 added, 156 removed, 399 maintained
#>   2006_vs_2009: 133 added, 160 removed, 395 maintained
#>   2006_vs_2010: 180 added, 123 removed, 432 maintained
#>   2006_vs_2011: 157 added, 157 removed, 398 maintained
#>   2006_vs_2012: 216 added, 168 removed, 387 maintained
#>   2006_vs_2013: 123 added, 255 removed, 300 maintained
#>   2006_vs_2014: 83 added, 321 removed, 234 maintained
#>   2007_vs_2008: 38 added, 223 removed, 436 maintained
#>   2007_vs_2009: 87 added, 218 removed, 441 maintained
#>   2007_vs_2010: 130 added, 177 removed, 482 maintained
#>   2007_vs_2011: 151 added, 255 removed, 404 maintained
#>   2007_vs_2012: 208 added, 264 removed, 395 maintained
#>   2007_vs_2013: 157 added, 393 removed, 266 maintained
#>   2007_vs_2014: 53 added, 395 removed, 264 maintained
#>   2008_vs_2009: 61 added, 7 removed, 467 maintained
#>   2008_vs_2010: 182 added, 44 removed, 430 maintained
#>   2008_vs_2011: 157 added, 76 removed, 398 maintained
#>   2008_vs_2012: 217 added, 88 removed, 386 maintained
#>   2008_vs_2013: 159 added, 210 removed, 264 maintained
#>   2008_vs_2014: 34 added, 191 removed, 283 maintained
#>   2009_vs_2010: 136 added, 52 removed, 476 maintained
#>   2009_vs_2011: 157 added, 130 removed, 398 maintained
#>   2009_vs_2012: 173 added, 98 removed, 430 maintained
#>   2009_vs_2013: 125 added, 230 removed, 298 maintained
#>   2009_vs_2014: 30 added, 241 removed, 287 maintained
#>   2010_vs_2011: 131 added, 188 removed, 424 maintained
#>   2010_vs_2012: 101 added, 110 removed, 502 maintained
#>   2010_vs_2013: 59 added, 248 removed, 364 maintained
#>   2010_vs_2014: 30 added, 325 removed, 287 maintained
#>   2011_vs_2012: 144 added, 96 removed, 459 maintained
#>   2011_vs_2013: 96 added, 228 removed, 327 maintained
#>   2011_vs_2014: 27 added, 265 removed, 290 maintained
#>   2012_vs_2013: 22 added, 202 removed, 401 maintained
#>   2012_vs_2014: 27 added, 313 removed, 290 maintained
#>   2013_vs_2014: 56 added, 162 removed, 261 maintained

# Create a cleaner visualization focusing on consecutive years only
consecutive_comparisons <- pakistan_temporal_comp$edge_changes[
    grep("^20\\d{2}_vs_20\\d{2}$", names(pakistan_temporal_comp$edge_changes))
]

# Extract consecutive year comparisons (e.g., 2002_vs_2003, not 2002_vs_2014)
consecutive_years <- data.frame()
for(comp_name in names(consecutive_comparisons)) {
    years <- strsplit(comp_name, "_vs_")[[1]]
    if(as.numeric(years[2]) - as.numeric(years[1]) == 1) {
        comp_data <- consecutive_comparisons[[comp_name]]
        consecutive_years <- rbind(consecutive_years, data.frame(
            year = years[2],
            added = comp_data$added,
            removed = comp_data$removed,
            maintained = comp_data$maintained,
            total = comp_data$added + comp_data$removed + comp_data$maintained
        ))
    }
}

# Calculate proportions for a cleaner view
consecutive_years <- consecutive_years %>%
    mutate(
        prop_stable = maintained / total,
        prop_change = (added + removed) / total
    )

# Simple line plot showing network stability over time
ggplot(consecutive_years, aes(x = as.numeric(year))) +
    geom_line(aes(y = prop_stable), color = "darkblue", linewidth = 1.2) +
    geom_point(aes(y = prop_stable), color = "darkblue", size = 3) +
    scale_y_continuous(labels = scales::percent, limits = c(0, 1)) +
    labs(
        title = "Stability in Pakistan's Ego Network Over Time",
        subtitle = "Proportion of relationships maintained from previous year",
        x = "Year",
        y = "Proportion of Stable Relationships"
    ) +
    theme_minimal() +
    annotate("text", x = 2008, y = 0.85, 
             label = paste0("Average stability: ", 
                           round(mean(consecutive_years$prop_stable) * 100, 1), "%"),
             size = 3.5)
```

![plot of chunk unnamed-chunk-14](figure/unnamed-chunk-14-1.png)

### Comparing Ego Network Structures Across Countries

We can also compare the structural properties of different countries' ego networks at a specific time point:


``` r
# Compare US and China ego network structures in 2012
compare_networks(
    list(
        "US_2012" = subset(us_ego, time='2012'),
        "China_2012" = subset(china_ego, time='2012')
    ),
    what = 'structure'
)
#> Network Comparison Results
#> ==========================
#> Type: cross_network 
#> Method: structural_comparison 
#> Networks compared: 2 
#> 
#> Summary Statistics:
#>     network n_nodes n_edges   density reciprocity transitivity mean_degree
#>     US_2012     123    8025 0.5304382   0.9700221    0.6958762     65.2439
#>  China_2012     112    6839 0.5452009   0.9698620    0.7121216     61.0625
```

This comparison reveals differences in how major powers structure their diplomatic neighborhoods. The `what = 'structure'` parameter compares network-level properties like density, reciprocity, and transitivity rather than individual edges.

## Strategic Analysis: Brokerage in Ego Networks

### Identifying Bridge Countries

Which countries in Pakistan's ego network serve as bridges to others?


``` r
# Calculate betweenness centrality within Pakistan's ego network for 2010
pakistan_2010_single <- subset(pakistan_ego_net, time = "2010")
pakistan_2010_stats <- summary_actor(pakistan_2010_single)

# Check what columns are available for directed networks
print("Available columns in summary_actor:")
#> [1] "Available columns in summary_actor:"
print(names(pakistan_2010_stats))
#>  [1] "actor"                 "degree_in"             "degree_out"           
#>  [4] "degree_total"          "prop_ties_in"          "prop_ties_out"        
#>  [7] "prop_ties_total"       "network_share_in"      "network_share_out"    
#> [10] "network_share_total"   "closeness_in"          "closeness_out"        
#> [13] "closeness_all"         "betweenness"           "authority_score"      
#> [16] "hub_score"             "strength_sum_in"       "strength_sum_out"     
#> [19] "strength_sum_total"    "strength_avg_in"       "strength_avg_out"     
#> [22] "strength_avg_total"    "strength_std_in"       "strength_std_out"     
#> [25] "strength_std_total"    "strength_median_in"    "strength_median_out"  
#> [28] "strength_median_total"

# Identify top brokers (using total_degree for directed networks)
top_brokers <- pakistan_2010_stats %>%
    arrange(desc(betweenness)) %>%
    head(10) %>%
    select(actor, betweenness, total_degree, in_degree, out_degree)
#> Error in `select()`:
#> ! Can't select columns that don't exist.
#> ✖ Column `total_degree` doesn't exist.

print("Top brokers in Pakistan's 2010 ego network:")
#> [1] "Top brokers in Pakistan's 2010 ego network:"
print(top_brokers)
#> Error: object 'top_brokers' not found

# Visualize brokerage positions
ggplot(pakistan_2010_stats, aes(x = total_degree, y = betweenness)) +
    geom_point(alpha = 0.6) +
    geom_text(data = top_brokers[1:5,], 
              aes(label = actor), 
              vjust = -0.5, size = 3) +
    labs(
        title = "Brokerage Positions in Pakistan's 2010 Ego Network",
        subtitle = "High betweenness indicates bridging role",
        x = "Total Degree (In + Out Connections)",
        y = "Betweenness Centrality"
    ) +
    theme_minimal()
#> Error: object 'top_brokers' not found
```

## Ego Networks and Network-Wide Phenomena

### From Local to Global: Ego Network Typologies

Let's classify countries based on their ego network properties:


``` r
# Extract ego networks for a sample of countries
sample_countries <- c("United States", "China", "Russian Federation", 
                     "Germany", "Japan", "Brazil", "India", "Pakistan",
                     "South Africa", "Egypt")

# Calculate properties for each
ego_metrics <- list()
for(country in sample_countries) {
    if(country %in% unique(icews$i)) {
        ego_net <- ego_netify(subset(netlet, time = "2010"), ego = country)
        summ <- summary(ego_net)
        
        ego_metrics[[country]] <- data.frame(
            country = country,
            density = summ$density,
            transitivity = summ$transitivity,
            avg_degree = summ$avg_degree,
            n_nodes = summ$num_actors
        )
    }
}
#> Error in data.frame(country = country, density = summ$density, transitivity = summ$transitivity, : arguments imply differing number of rows: 1, 0

ego_metrics_df <- bind_rows(ego_metrics)

# Create typology based on density and transitivity
ggplot(ego_metrics_df, aes(x = density, y = transitivity)) +
    geom_point(size = 3) +
    geom_text(aes(label = country), vjust = -0.5, size = 3) +
    geom_hline(yintercept = median(ego_metrics_df$transitivity), 
               linetype = "dashed", alpha = 0.5) +
    geom_vline(xintercept = median(ego_metrics_df$density), 
               linetype = "dashed", alpha = 0.5) +
    labs(
        title = "Ego Network Typology",
        subtitle = "Countries clustered by local network structure (2010)",
        x = "Ego Network Density",
        y = "Ego Network Transitivity"
    ) +
    theme_minimal() +
    annotate("text", x = 0.3, y = 0.8, label = "Tight Clusters", fontface = "italic") +
    annotate("text", x = 0.7, y = 0.8, label = "Dense Hubs", fontface = "italic") +
    annotate("text", x = 0.3, y = 0.2, label = "Sparse Stars", fontface = "italic") +
    annotate("text", x = 0.7, y = 0.2, label = "Loose Webs", fontface = "italic")
#> Error in `geom_point()`:
#> ! Problem while computing aesthetics.
#> ℹ Error occurred in the 1st layer.
#> Caused by error:
#> ! object 'transitivity' not found
```

### Dynamic Thresholds: Exploring Neighborhood Definitions

The `threshold` parameter in `ego_netify()` lets us explore how neighborhood definitions affect network structure:


``` r
# Extract US ego network with different thresholds
thresholds <- c(0, 10, 20, 50)
threshold_summaries <- list()

for(thresh in thresholds) {
    us_ego_temp <- ego_netify(
        subset(netlet, time = "2010"), 
        ego = "United States",
        threshold = thresh
    )
    
    # Store summary for this threshold
    temp_summary <- summary(us_ego_temp)
    threshold_summaries[[as.character(thresh)]] <- data.frame(
        threshold = thresh,
        n_alters = temp_summary$num_actors - 1,  # Exclude ego
        density = temp_summary$density,
        avg_degree = temp_summary$avg_degree
    )
}
#> Error in data.frame(threshold = thresh, n_alters = temp_summary$num_actors - : arguments imply differing number of rows: 1, 0

threshold_comparison <- bind_rows(threshold_summaries)

# Visualize threshold effects
p1 <- ggplot(threshold_comparison, aes(x = threshold, y = n_alters)) +
    geom_line(linewidth = 1.2) +
    geom_point(size = 3) +
    labs(
        title = "Threshold Effects on Ego Network Size",
        x = "Cooperation Threshold",
        y = "Number of Alters"
    ) +
    theme_minimal()

p2 <- ggplot(threshold_comparison, aes(x = threshold, y = density)) +
    geom_line(linewidth = 1.2) +
    geom_point(size = 3) +
    labs(
        title = "Threshold Effects on Network Density",
        x = "Cooperation Threshold",
        y = "Ego Network Density"
    ) +
    theme_minimal()

p1 + p2
#> Error in `geom_line()`:
#> ! Problem while computing aesthetics.
#> ℹ Error occurred in the 1st layer.
#> Caused by error:
#> ! object 'threshold' not found
```

**Interpretation**: As we increase the threshold, the US ego network becomes smaller but denser, revealing a core group of countries with strong cooperative ties. This demonstrates how threshold choices can reveal different layers of international relationships.

## Advanced Applications

### Ego Networks in Multilayer Analysis

How do ego networks differ across cooperation types?


``` r
# Create multilayer ego network for US in 2010
icews_2010 <- icews[icews$year == 2010, ]

# Verbal cooperation ego network
verbal_net_2010 <- netify(
    icews_2010,
    actor1 = "i", actor2 = "j",
    weight = "verbCoop",
    symmetric = FALSE
)
us_verbal_ego <- ego_netify(verbal_net_2010, ego = "United States")

# Material cooperation ego network  
material_net_2010 <- netify(
    icews_2010,
    actor1 = "i", actor2 = "j",
    weight = "matlCoop",
    symmetric = FALSE
)
us_material_ego <- ego_netify(material_net_2010, ego = "United States")

# Compare alter sets
verbal_alters <- setdiff(rownames(us_verbal_ego), "United States")
material_alters <- setdiff(rownames(us_material_ego), "United States")

# Create comparison data
layer_comparison <- data.frame(
    layer = c("Verbal Only", "Both", "Material Only"),
    count = c(
        length(setdiff(verbal_alters, material_alters)),
        length(intersect(verbal_alters, material_alters)),
        length(setdiff(material_alters, verbal_alters))
    )
)

ggplot(layer_comparison, aes(x = layer, y = count, fill = layer)) +
    geom_col() +
    scale_fill_manual(values = c("Verbal Only" = "lightblue",
                                 "Both" = "purple",
                                 "Material Only" = "darkgreen")) +
    labs(
        title = "US Ego Networks Across Cooperation Types (2010)",
        subtitle = "Most relationships are verbal-only",
        x = "",
        y = "Number of Countries"
    ) +
    theme_minimal() +
    guides(fill = "none")
```

![plot of chunk unnamed-chunk-19](figure/unnamed-chunk-19-1.png)

### Ego Network Stability Over Time

Which actors maintain stable positions in ego networks?


``` r
# Analyze stability in US ego network
us_ego_longit <- ego_netify(netlet, ego = "United States")

# Track presence across years
years <- names(us_ego_longit)
alter_presence <- list()

for(year in years) {
    year_net <- subset(us_ego_longit, time = year)
    alters <- setdiff(rownames(year_net), "United States")
    for(alter in alters) {
        if(is.null(alter_presence[[alter]])) {
            alter_presence[[alter]] <- c()
        }
        alter_presence[[alter]] <- c(alter_presence[[alter]], year)
    }
}

# Calculate stability score (proportion of years present)
stability_scores <- data.frame(
    actor = names(alter_presence),
    n_years = sapply(alter_presence, length),
    stability = sapply(alter_presence, length) / length(years)
) %>%
    arrange(desc(stability), desc(n_years))

# Show most stable partners
cat("Most stable partners in US ego network:\n")
#> Most stable partners in US ego network:
head(stability_scores, 10)
#>                   actor n_years stability
#> Afghanistan Afghanistan      13         1
#> Albania         Albania      13         1
#> Algeria         Algeria      13         1
#> Argentina     Argentina      13         1
#> Armenia         Armenia      13         1
#> Australia     Australia      13         1
#> Azerbaijan   Azerbaijan      13         1
#> Bangladesh   Bangladesh      13         1
#> Belarus         Belarus      13         1
#> Belgium         Belgium      13         1

# Visualize stability distribution
ggplot(stability_scores, aes(x = stability)) +
    geom_histogram(bins = 20, color = "white") +
    labs(
        title = "Stability in US Ego Network",
        subtitle = "Distribution of alter persistence (2002-2014)",
        x = "Proportion of Years Present",
        y = "Number of Countries"
    ) +
    theme_minimal()
```

![plot of chunk unnamed-chunk-20](figure/unnamed-chunk-20-1.png)

## Practical Applications and Recommendations

### When to Use Ego Network Analysis

**Use ego networks when:**

- Studying how individual actors navigate their social environments
- Computational constraints prevent full network analysis
- Theory focuses on local mechanisms (e.g., triadic closure, local clustering)
- Comparing network positions across different types of actors
- Understanding network inequality and stratification

**Combine with full network analysis when:**

- Connecting local patterns to global outcomes
- Testing theories about network position and behavior
- Identifying key players for targeted interventions
- Understanding cascade and diffusion processes

### Best Practices for Ego Network Analysis

1. **Threshold Selection**: 
   - For unweighted networks: Use threshold = 0
   - For weighted networks: Default (mean) often works well
   - Consider multiple thresholds for sensitivity analysis

2. **Directional Considerations**:
   - "out" for studying an actor's influence reach
   - "in" for studying an actor's support network
   - "any" for comprehensive neighborhood analysis

3. **Temporal Analysis**:
   - Track ego network evolution for strategic changes
   - Identify stable vs. dynamic components
   - Link changes to external events or actor attributes

4. **Comparative Analysis**:
   - Always compare multiple ego networks
   - Use actor attributes to explain variation
   - Consider both size and structure

## tl;dr

Ego network analysis in `netify` reveals how actors build and maintain their immediate network neighborhoods:

1. **Extract ego networks** with `ego_netify()` to focus on local structures
2. **Compare across actors** to identify different networking strategies
3. **Track temporal evolution** to understand relationship dynamics
4. **Analyze with attributes** to test theories about homophily and influence
5. **Use `compare_networks()`** to quantify changes and similarities
6. **Combine with multilayer analysis** for comprehensive understanding

Most importantly: Ego networks bridge the gap between individual behavior and system-wide patterns, making them essential for understanding how networks actually work in practice!

## References

- Sundberg, Ralph and Erik Melander (2013) Introducing the UCDP Georeferenced Event Dataset. Journal of Peace Research 50(4).
