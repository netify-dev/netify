## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  dev = 'png', dpi = 150,
  cache = FALSE,
  echo = TRUE,
  warning = FALSE,
  message = FALSE
)

## -----------------------------------------------------------------------------
library(netify)
library(ggplot2)
library(peacesciencer)
library(tidyverse)
library(countrycode)

## -----------------------------------------------------------------------------
# Download peacesciencer external data if needed
peacesciencer::download_extdata()

# Create dyadic dataset for a recent 5-year period
cow_dyads <- create_dyadyears(subset_years = c(2010:2014)) |>
  # Add conflict data (we'll use inverse for cooperation)
  add_cow_mids() |>
  # Add capital distance
  add_capital_distance() |>
  # Add democracy scores (V-Dem polyarchy)
  add_democracy() |>
  # Add GDP data
  add_sdp_gdp() |>
  # Add material capabilities
  add_nmc() |>
  # Add ATOP alliance data
  add_atop_alliance()

# Create alliance cooperation measure based on ATOP alliance types
cow_dyads <- cow_dyads |>
  mutate(
    # Create alliance intensity score (0-5 based on number of pledge types)
    alliance_score = atop_defense + atop_offense + atop_neutral + atop_nonagg + atop_consul,
    # Normalize to 0-1 scale
    alliance_norm = alliance_score / 5,
    # Create cooperation score: alliance intensity without conflict
    cooperation = alliance_norm,
    # cooperation = alliance_norm * (1 - cowmidonset),
    # Add region information
    region1 = countrycode(ccode1, "cown", "region"),
    region2 = countrycode(ccode2, "cown", "region"),
    # Log transform some variables
    log_gdp1 = log(wbgdp2011est1 + 1),
    log_gdp2 = log(wbgdp2011est2 + 1),
    log_capdist = log(capdist + 1)
  )

# Filter to 2012 for cross-sectional analysis
cow_2012 <- cow_dyads |>
  filter(year == 2012)

## -----------------------------------------------------------------------------
# Create alliance network
alliance_net <- netify(
  cow_2012,
  actor1 = 'ccode1', actor2 = 'ccode2',
  symmetric = TRUE,
  weight = 'cooperation'
)

# Print object
print(alliance_net)

## -----------------------------------------------------------------------------
# Prepare nodal data with country attributes
nodal_data <- cow_2012 |>
  select(
    ccode1, region1, v2x_polyarchy1, 
    log_gdp1, cinc1
    ) |>
  distinct() |>
  rename(
    actor = ccode1,
    region = region1,
    democracy = v2x_polyarchy1,
    log_gdp = log_gdp1,
    mil_capability = cinc1
  ) |>
  mutate(
    # Create democracy categories based on V-Dem scores
    regime_type = case_when(
      democracy >= 0.6 ~ "Democracy",
      democracy >= 0.4 ~ "Hybrid",
      democracy < 0.4 ~ "Autocracy",
      TRUE ~ "Unknown"
    ),
    # Create development categories
    development = case_when(
      log_gdp >= quantile(log_gdp, 0.75, na.rm = TRUE) ~ "High",
      log_gdp >= quantile(log_gdp, 0.25, na.rm = TRUE) ~ "Medium",
      TRUE ~ "Low"
    )
  )

# Add country names for better interpretation
nodal_data$country_name <- countrycode(nodal_data$actor, "cown", "country.name")

# Add nodal variables to network
alliance_net <- add_node_vars(alliance_net, nodal_data, actor = "actor")

## -----------------------------------------------------------------------------
# Prepare dyadic data
dyad_data <- cow_2012 |>
  select(ccode1, ccode2, log_capdist, alliance_norm, atop_defense) |>
  rename(
    actor1 = ccode1,
    actor2 = ccode2,
    geographic_distance = log_capdist,
    alliance_intensity = alliance_norm,
    defense_alliance = atop_defense
  )

# Add dyadic variables to network
alliance_net <- add_dyad_vars(
  alliance_net, 
  dyad_data = dyad_data,
  actor1 = "actor1",
  actor2 = "actor2",
  dyad_vars = c("geographic_distance", "alliance_intensity", "defense_alliance"),
  dyad_vars_symmetric = c(TRUE, TRUE, TRUE)
)

## -----------------------------------------------------------------------------
# Test if countries with similar democracy levels form more alliances
democracy_homophily <- homophily(
  alliance_net,                  # Our network object
  attribute = "democracy",       # Node attribute to analyze
  method = "correlation",        # Method for continuous variables
  significance_test = TRUE       # Perform statistical significance test
)

print(democracy_homophily)

# Build summary message
democracy_summary <- paste0(
  "**Democracy Homophily Results:**\n\n",
  "- Homophily correlation: ", round(democracy_homophily$homophily_correlation, 3), "\n",
  "- Avg similarity among allies: ", round(democracy_homophily$mean_similarity_connected, 3), "\n",
  "- Avg similarity among non-allies: ", round(democracy_homophily$mean_similarity_unconnected, 3), "\n",
  "- P-value: ", round(democracy_homophily$p_value, 3), "\n",
  if(democracy_homophily$p_value < 0.05) {
    "→ Democracies significantly tend to ally with similarly democratic countries\n"
  } else {
    "→ No significant democracy-based alliance preferences detected\n"
  }
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(democracy_summary)

## ----fig.width=8, fig.height=5------------------------------------------------
# Visualize the democracy homophily pattern
plot_homophily(democracy_homophily, alliance_net, 
               type = "distribution", 
               attribute = "democracy",
               method = "correlation",
               sample_size = 5000) +  # Sample for faster plotting with large networks
  labs(subtitle = "Allied countries show greater similarity in democracy scores") +
  # Expand x-axis limits to show full distribution
  xlim(c(-1, 1))

## -----------------------------------------------------------------------------
head(attr(alliance_net, 'nodal_data'))

## -----------------------------------------------------------------------------
# Test using categorical regime types
regime_homophily <- homophily(
  alliance_net, 
  attribute = "regime_type", 
  method = "categorical",
  significance_test = TRUE)

print(regime_homophily)

# Build regime type summary message
regime_summary <- paste0(
  "**Regime Type Homophily Results:**\n\n",
  "- Homophily score: ", round(regime_homophily$homophily_correlation, 3), "\n",
  "- Same-regime alliances: ", round(regime_homophily$mean_similarity_connected * 100, 1), "%\n",
  "- Different-regime alliances: ", round((1 - regime_homophily$mean_similarity_connected) * 100, 1), "%\n",
  "- Expected if random: ", round(regime_homophily$mean_similarity_unconnected * 100, 1), "%\n",
  "- P-value: ", round(regime_homophily$p_value, 3), "\n",
  if(regime_homophily$p_value < 0.05 && regime_homophily$homophily_correlation > 0.1) {
    "→ Countries strongly prefer allies with similar political systems\n"
  } else {
    "→ Regime type doesn't significantly influence alliance formation\n"
  }
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(regime_summary)

## ----fig.width=8, fig.height=5------------------------------------------------
# Visualize regime type homophily
plot_homophily(regime_homophily, alliance_net,
               type = "distribution",
               attribute = "regime_type", 
               method = "categorical",
               sample_size = 5000) +
  labs(title = "Regime Type Homophily in Alliance Networks",
       subtitle = "Do similar political systems form more alliances?")

## -----------------------------------------------------------------------------
# Test if countries with similar GDP levels form more alliances
gdp_homophily <- homophily(
  alliance_net, 
  attribute = "log_gdp", 
  method = "correlation",
  significance_test = TRUE)

print(gdp_homophily)

# Build economic development summary message
economic_summary <- paste0(
  "**Economic Development Homophily Results:**\n\n",
  "- Homophily correlation: ", round(gdp_homophily$homophily_correlation, 3), "\n",
  "- Similarity among allies: ", round(gdp_homophily$mean_similarity_connected, 3), "\n",
  "- Similarity among non-allies: ", round(gdp_homophily$mean_similarity_unconnected, 3), "\n",
  "- P-value: ", round(gdp_homophily$p_value, 3), "\n",
  if(gdp_homophily$p_value < 0.05 && gdp_homophily$homophily_correlation > 0) {
    "→ Countries at similar development levels are more likely to form alliances\n"
  } else {
    "→ Economic development levels don't significantly predict alliance patterns\n"
  }
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(economic_summary)

## -----------------------------------------------------------------------------
# Test regional homophily
region_homophily <- homophily(
  alliance_net, 
  attribute = "region", 
  method = "categorical",
  significance_test = TRUE)

print(region_homophily)

# Build regional clustering summary message
regional_summary <- paste0(
  "**Regional Clustering Results:**\n\n",
  "- Homophily score: ", round(region_homophily$homophily_correlation, 3), "\n",
  "- Within-region alliances: ", round(region_homophily$mean_similarity_connected, 3), "\n",
  "- Cross-region alliances: ", round(region_homophily$mean_similarity_unconnected, 3), "\n"
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(regional_summary)

## -----------------------------------------------------------------------------
# Analyze mixing patterns by regime type
regime_mixing <- mixing_matrix(
  alliance_net,                # Network object
  attribute = "regime_type",   # Categorical attribute to analyze
  normalized = TRUE            # Normalize to show proportions
)

# Display the mixing matrix
knitr::kable(round(regime_mixing$mixing_matrices[[1]], 3), 
             caption = "Regime Type Alliance Matrix (normalized)",
             align = "c")

# Build key insights summary message
regime_mixing_summary <- paste0(
  "**Key Insights from mixing_matrix():**\n\n",
  "- Assortativity: ", round(regime_mixing$summary_stats$assortativity, 3), "\n",
  "  (Positive = similar types connect more; Negative = different types connect more)\n",
  "- Proportion of within-type alliances: ", round(regime_mixing$summary_stats$diagonal_proportion, 3), "\n",
  "  (Higher values indicate more homophily)\n"
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(regime_mixing_summary)

## -----------------------------------------------------------------------------
# Analyze mixing patterns by region
region_mixing <- mixing_matrix(
  alliance_net, 
  attribute = "region",
  normalized = TRUE,
  by_row = TRUE)

# Display regional mixing matrix with header
regional_mixing_header <- "**Regional Alliance Matrix (row-normalized):**\n\n"

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(regional_mixing_header)

## -----------------------------------------------------------------------------
knitr::kable(round(region_mixing$mixing_matrices[[1]], 3),
             caption = "Regional Alliance Matrix (row-normalized)",
             align = "c")

## ----fig.width=9, fig.height=7------------------------------------------------
# Visualize regional mixing patterns
plot_mixing_matrix(region_mixing,
                  show_values = TRUE,
                  value_digits = 2,
                  text_size = 3,
                  text_color_threshold=.7,
                  diagonal_emphasis = TRUE,
                  reorder_categories = FALSE) +
  labs(title = "Regional Alliance Patterns",
       subtitle = "Within-region vs cross-region alliance formation",
       x = "Allied with region",
       y = "From region") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
        axis.text.y = element_text(size = 10))

## -----------------------------------------------------------------------------
# How do regime types interact across regions?
cross_mixing <- mixing_matrix(
  alliance_net, 
  attribute = "regime_type",
  row_attribute = "region",
  normalized = TRUE)

# Display cross-dimensional analysis with header
cross_mixing_header <- "**How different regime types form alliances across regions:**\n\n"

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(cross_mixing_header)

## -----------------------------------------------------------------------------
knitr::kable(round(cross_mixing$mixing_matrices[[1]], 3),
             caption = "Cross-dimensional Analysis: Regime Types Across Regions",
             align = "c")

## -----------------------------------------------------------------------------
# Test correlation between geographic distance and alliance formation
geo_correlation <- dyad_correlation(
  alliance_net,                      # Network object
  dyad_vars = "geographic_distance", # Dyadic variable to analyze
  method = "pearson",                # Correlation method
  significance_test = TRUE           # Test statistical significance
)

# Build geographic distance analysis summary
geo_summary <- paste0(
  "**Geographic Distance and Alliance Formation (dyad_correlation results):**\n\n",
  "- Correlation coefficient: ", round(geo_correlation$correlation, 3), "\n",
  "- P-value: ", round(geo_correlation$p_value, 3), "\n",
  "- Number of dyads analyzed: ", geo_correlation$n_dyads[1], "\n\n",
  if(geo_correlation$correlation < -0.1 && geo_correlation$p_value < 0.05) {
    "✓ Geography matters: Countries form more alliances with nearby nations.\n  (Negative correlation = shorter distance, more alliances)\n"
  } else if(geo_correlation$correlation > 0.1 && geo_correlation$p_value < 0.05) {
    "✗ Surprising: Greater distance associated with more alliances.\n  (Positive correlation = greater distance, more alliances)\n"
  } else {
    "→ Geography shows no clear effect on alliance patterns.\n  (No significant correlation detected)\n"
  }
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(geo_summary)

## -----------------------------------------------------------------------------
# Test both geographic distance and alliance intensity
multi_dyad_correlation <- dyad_correlation(
  alliance_net,
  dyad_vars = c("geographic_distance", "alliance_intensity", "defense_alliance"),
  method = "pearson",
  significance_test = TRUE
)

# Build multiple dyadic variables summary
multi_dyad_summary <- paste0(
  "**Multiple Dyadic Variables Analysis:**\n\n",
  paste(sapply(1:nrow(multi_dyad_correlation), function(i) {
    paste0(
      "**", multi_dyad_correlation$dyad_var[i], ":**\n",
      "  - Correlation: ", round(multi_dyad_correlation$correlation[i], 3), "\n",
      "  - P-value: ", round(multi_dyad_correlation$p_value[i], 3), "\n"
    )
  }), collapse = "\n")
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(multi_dyad_summary)

## -----------------------------------------------------------------------------
# Run comprehensive analysis with all features
comprehensive_analysis <- attribute_report(
  alliance_net,
  # Node-level variables to analyze
  node_vars = c("region", "regime_type", "democracy", "log_gdp", "mil_capability"),
  
  # Dyad-level variables to analyze  
  dyad_vars = c("geographic_distance", "alliance_intensity", "defense_alliance"),
  
  # Include all analysis types
  include_centrality = TRUE,          # Correlate attributes with network position
  include_homophily = TRUE,           # Test if similar nodes connect
  include_mixing = TRUE,              # Examine interaction patterns
  include_dyadic_correlations = TRUE, # Analyze dyadic predictors
  
  # Specify which centrality measures to compute
  centrality_measures = c("degree", "betweenness", "closeness"),
  
  # Perform significance tests
  significance_test = TRUE
)

## -----------------------------------------------------------------------------
# Build homophily analysis header
homophily_header <- paste0(
  "**=== HOMOPHILY ANALYSIS ===**\n\n",
  "Do similar countries form more alliances?\n\n"
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(homophily_header)
homophily_summary <- comprehensive_analysis$homophily_analysis

# Create a more informative display
homophily_display <- homophily_summary |>
  mutate(
    significance = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01 ~ "**",
      p_value < 0.05 ~ "*",
      TRUE ~ "n.s."
    ),
    interpretation = case_when(
      homophily_correlation > 0.3 & p_value < 0.05 ~ "Strong homophily",
      homophily_correlation > 0.1 & p_value < 0.05 ~ "Moderate homophily",
      homophily_correlation > 0 & p_value < 0.05 ~ "Weak homophily",
      p_value >= 0.05 ~ "No significant pattern",
      TRUE ~ "Heterophily"
    )
  )

knitr::kable(
  homophily_display[, 
  c(
    "attribute", "method", 
    "homophily_correlation", 
    "p_value", "significance", 
    "interpretation")],
  caption = "Homophily Analysis Results",
  col.names = c("Attribute", "Method", "Homophily Correlation", "P-value", "Significance", "Interpretation"),
  digits = 3,
  align = "c"
)

## -----------------------------------------------------------------------------
# Build power and influence header
power_header <- paste0(
  "**=== POWER AND INFLUENCE ===**\n\n",
  "What makes countries central in the alliance network?\n\n"
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(power_header)
centrality_summary <- comprehensive_analysis$centrality_correlations

# Show all centrality correlations with interpretation
centrality_display <- centrality_summary |>
  mutate(
    interpretation = case_when(
      correlation > 0.3 & p_value < 0.05 ~ "Strongly associated with centrality",
      correlation > 0.1 & p_value < 0.05 ~ "Moderately associated with centrality",
      correlation < -0.1 & p_value < 0.05 ~ "Negatively associated with centrality",
      p_value < 0.05 ~ "Weakly associated with centrality",
      TRUE ~ "Not significantly related to centrality"
    )
  ) |>
  arrange(p_value)

knitr::kable(
  centrality_display[1:10, 
  c(
    "node_var", "centrality_measure", 
    "correlation", "p_value", 
    "interpretation")],
  caption = "Top 10 Centrality-Attribute Correlations",
  col.names = c("Node Variable", "Centrality Measure", "Correlation", "P-value", "Interpretation"),
  digits = 3,
  align = "c"
)

## -----------------------------------------------------------------------------
# Build relationship factors header
relationship_header <- paste0(
  "**=== RELATIONSHIP FACTORS ===**\n\n",
  "What dyadic factors predict alliance formation?\n\n"
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(relationship_header)
dyadic_summary <- comprehensive_analysis$dyadic_correlations
knitr::kable(dyadic_summary[, c("dyad_var", "correlation", "p_value")],
             caption = "Dyadic Variables Analysis",
             col.names = c("Dyadic Variable", "Correlation", "P-value"),
             digits = 3,
             align = "c")

## -----------------------------------------------------------------------------
# Create a binary democracy indicator
nodal_data_binary <- nodal_data |>
  mutate(is_democracy = ifelse(regime_type == "Democracy", 1, 0))

alliance_net_binary <- add_node_vars(
  alliance_net, 
  nodal_data_binary[, c("actor", "is_democracy")], 
  actor = "actor")

# Test democratic peace using binary measure
dem_peace_test <- homophily(
  alliance_net_binary, 
  attribute = "is_democracy", 
  method = "categorical",
  significance_test = TRUE)

# Build democratic peace hypothesis summary
dem_peace_summary <- paste0(
  "**Democratic Peace Hypothesis Test:**\n\n",
  "- Effect size: ", round(dem_peace_test$homophily_correlation, 3), "\n",
  "- P-value: ", round(dem_peace_test$p_value, 3), "\n",
  "- Conclusion: ", ifelse(
    dem_peace_test$p_value < 0.05, 
    "Democracies significantly prefer forming alliances with other democracies",
    "No significant democratic preference"), "\n"
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(dem_peace_summary)

## -----------------------------------------------------------------------------
# Test military capability homophily
power_homophily <- homophily(
  alliance_net, 
  attribute = "mil_capability", 
  method = "correlation",
  significance_test = TRUE)

# Build power politics hypothesis summary
power_politics_summary <- paste0(
  "**Power Politics Hypothesis:**\n\n",
  "- Correlation: ", round(power_homophily$homophily_correlation, 3), "\n",
  "- P-value: ", round(power_homophily$p_value, 3), "\n",
  "- Interpretation: ", ifelse(power_homophily$p_value < 0.05 & power_homophily$homophily_correlation > 0,
    "Powerful countries prefer forming alliances with other powerful countries",
    ifelse(power_homophily$p_value < 0.05 & power_homophily$homophily_correlation < 0,
      "Powerful countries tend to form alliances with less powerful countries (heterophily)",
      "No evidence of power-based alliance preferences")), "\n"
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(power_politics_summary)

## -----------------------------------------------------------------------------
# First add network statistics to the netify object
alliance_net <- add_node_vars(
  alliance_net,
  summary_actor(alliance_net),
  actor = "actor"
)

## ----fig.width=8, fig.height=6------------------------------------------------
# 
plot(alliance_net,
     # Node aesthetics
     node_color_by = "region",
     node_color_label = "",
     node_shape_by = "regime_type",
     node_shape_label = "",
     node_size_by = "degree",
     node_size_label = "Degree",
     node_fill = "white",
     # Edge aesthetics - make edges much more subtle
     edge_color = "grey50",  # Darker gray for visibility
     edge_linewidth = 0.5,   # Slightly thicker for visible edges
     edge_alpha_label='Alliance Strength (scaled)',
     layout = "nicely",  
     seed = 6886) +
  ggtitle("ATOP Network") +
  theme(legend.position='right')

## ----fig.width=10, fig.height=6-----------------------------------------------
# Use plot_homophily for a comparison plot
plot_homophily(comprehensive_analysis$homophily_analysis, 
               type = "comparison") +
  labs(title = "Alliance Formation Patterns: Which Attributes Matter?",
       subtitle = "Homophily analysis reveals how similarity drives international cooperation")

## ----fig.width=10, fig.height=8-----------------------------------------------
# Prepare data for centrality visualization
centrality_viz <- comprehensive_analysis$centrality_correlations |>
  filter(p_value < 0.1) |>  # Show marginally significant results
  mutate(
    significant = p_value < 0.05,
    node_var = factor(node_var),
    centrality_measure = factor(
      centrality_measure,
      levels = c("degree", "betweenness", "closeness"))
  )

if(nrow(centrality_viz) > 0) {
  ggplot(centrality_viz, aes(x = correlation, y = node_var, color = significant)) +
    geom_segment(
      aes(
        x = 0, xend = correlation, y = node_var, yend = node_var),
      size = 1) +
    geom_point(size = 3) +
    facet_wrap(~centrality_measure, ncol = 1) +
    geom_vline(xintercept = 0, linetype = "dashed", color = "gray50") +
    scale_color_manual(values = c("FALSE" = "gray60", "TRUE" = "#2E86AB"),
                       labels = c("FALSE" = "Not significant", "TRUE" = "(p < 0.05)")) +
    labs(title = "What Makes Countries Central in the Alliance Network?",
         subtitle = "Correlation between node attributes and centrality measures",
         x = "Correlation with Centrality",
         y = "Node Attribute",
         color = "") +
    theme_minimal() +
    theme(panel.grid.major.y = element_blank())
} else {
  no_centrality_msg <- "**No significant centrality correlations to visualize.**\n"
  cat(no_centrality_msg)
}

## ----fig.width=8, fig.height=6------------------------------------------------
# Create a heatmap of the regime mixing matrix using plot_mixing_matrix
plot_mixing_matrix(
    regime_mixing,
    show_values = TRUE,
    diagonal_emphasis = TRUE,
    text_color_threshold=.9
  ) +
  labs(title = "Regime Type Alliance Patterns",
       subtitle = "How different regime types interact in the network",
       x = "Allied with...",
       y = "Regime type")

