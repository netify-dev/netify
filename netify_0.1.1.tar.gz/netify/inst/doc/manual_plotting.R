## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  dev = 'png', dpi = 150,
  cache = FALSE,
  echo = TRUE
)

## -----------------------------------------------------------------------------
library(netify)
library(ggplot2)

## -----------------------------------------------------------------------------
if(!'ggnewscale' %in% rownames(installed.packages())){
  install.packages('ggnewscale', repos='https://cloud.r-project.org') }
library(ggnewscale)

## -----------------------------------------------------------------------------
# load icews data
data(icews)

# choose attributes
nvars = c( 'i_polity2', 'i_log_gdp', 'i_log_pop' )
dvars = c( 'matlCoop', 'verbConf', 'matlConf' )

# create a netify object
netlet = netify(
    icews, 
    actor1='i', actor2='j',
    time = 'year',
    symmetric=FALSE, weight='verbCoop',
    mode='unipartite', sum_dyads=FALSE,
    actor_time_uniform=TRUE, actor_pds=NULL,
    diag_to_NA=TRUE, missing_to_zero=TRUE,
    nodal_vars = nvars, 
    dyad_vars = dvars
)

# subset to a few actors
actors_to_keep = c(
  'Australia', 'Brazil',
  'Canada', 'Chile', 'China',
  'Colombia', 'Egypt', 'Ethiopia',
  'France', 'Germany', 'Ghana', 
  'Hungary', 'India', 'Indonesia', 
  'Iran, Islamic Republic Of', 
  'Israel', 'Italy', 'Japan', 'Kenya', 
  "Korea, Democratic People's Republic Of",
  'Korea, Republic Of', 'Nigeria', 'Pakistan', 
  'Qatar', 'Russian Federation', 'Saudi Arabia',
  'South Africa', 'Spain', 'Sudan', 
  'Syrian Arab Republic', 'Thailand', 
  'United Kingdom', 'United States', 
  'Zimbabwe' )
netlet = subset_netify(
  netlet, 
  actors = actors_to_keep
)

# print
netlet

## -----------------------------------------------------------------------------
# create a data frame for plotting
plot_data = net_plot_data(netlet)

# get relevant dfs
net_dfs = plot_data$net_dfs

# check structure of what's here
str(net_dfs)

# check the first few rows of the edge data
head(net_dfs$edge_data)

# check the first few rows of the nodal data
head(net_dfs$nodal_data)

## ----fig.width=9, fig.height=8------------------------------------------------
ggplot() + 
	geom_segment(
		data = net_dfs$edge_data,
		aes(
			x=x1, 
			y=y1, 
			xend=x2, 
			yend=y2
		),
		color='lightgrey',
		alpha=.2
	) +
	geom_point(
		data = net_dfs$nodal_data,
		aes(
			x=x, 
			y=y,
			size=i_log_pop, 
			color=i_polity2
		)
	) +
  labs(
    color='Polity', 
    size='Log(Pop.)'
  ) +
	scale_color_gradient(low='#a6bddb', high='#014636') +
	facet_wrap(~time, scales='free') +
	theme_netify()

## -----------------------------------------------------------------------------
# create a df using mds instead 
plot_data_mds = net_plot_data(netlet, 
    list(
        layout='mds'
        )
    )

# see new x-y coordinates
lapply(plot_data_mds$net_dfs, head)

## -----------------------------------------------------------------------------
if(!'dplyr' %in% rownames(installed.packages())){
  install.packages('dplyr', repos='https://cloud.r-project.org') }
library(dplyr)

# create high_matlConf variable
net_dfs$edge_data = net_dfs$edge_data |>
    group_by(time) |>
    mutate(
        high_matlConf = matlConf > mean(matlConf, na.rm=TRUE)
    ) |>
    ungroup() |>
    as.data.frame()

# check
head(net_dfs$edge_data)

## ----fig.width=9, fig.height=8------------------------------------------------
# color line segments by this new variable
ggplot() + 
	geom_segment(
		data = net_dfs$edge_data,
		aes(
			x=x1, 
			y=y1, 
			xend=x2, 
			yend=y2,
            color=high_matlConf
		),
		alpha=.2
	) +
    scale_color_manual(
      name='', 
      values=c('grey', 'red'),
      labels=c('Below Avg. Matl. Conf', 'Above Avg.')
      ) +
    new_scale_color() +
	geom_point(
		data = net_dfs$nodal_data,
		aes(
			x=x, 
			y=y,
			size=i_log_pop, 
			color=i_polity2
		)
	) +
	scale_color_gradient(
	  name='Polity',
	  low='#a6bddb', high='#014636') +
  labs(
    size='Log(Pop.)'
  ) +
	facet_wrap(~time, scales='free') +
	theme_netify() +
  theme(
    legend.position='right'
  )

