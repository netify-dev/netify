## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  dev = 'png', dpi = 150,
  cache = FALSE,
  echo = TRUE,
  warning = FALSE,
  message = FALSE
)

## -----------------------------------------------------------------------------
library(netify)
library(ggplot2)
library(tidyverse)
library(patchwork)

## -----------------------------------------------------------------------------
# Load ICEWS data
data(icews)

# Take a peek
head(icews)

## -----------------------------------------------------------------------------
# Create networks for different interaction types in 2002
icews_2002 <- icews[icews$year == 2002, ]

# Verbal cooperation network
verb_coop_2002 <- netify(
  icews_2002,
  actor1 = 'i', actor2 = 'j',
  weight = 'verbCoop',
  symmetric = FALSE
)

# Material cooperation network  
matl_coop_2002 <- netify(
  icews_2002,
  actor1 = 'i', actor2 = 'j',
  weight = 'matlCoop',
  symmetric = FALSE
)

# Verbal conflict network
verb_conf_2002 <- netify(
  icews_2002,
  actor1 = 'i', actor2 = 'j',
  weight = 'verbConf',
  symmetric = FALSE
)

# Material conflict network
matl_conf_2002 <- netify(
  icews_2002,
  actor1 = 'i', actor2 = 'j',
  weight = 'matlConf',
  symmetric = FALSE
)

## -----------------------------------------------------------------------------
# Compare verbal vs material cooperation
coop_comparison <- compare_networks(
  list(
    verbal = verb_coop_2002,
    material = matl_coop_2002
  ),
  method = "all"
)

# Display comparison results
coop_comparison

# Interpret results
cat("\n=== INTERPRETATION ===\n")
if(coop_comparison$summary$correlation > 0.7) {
  cat("Strong alignment: Countries that cooperate verbally tend to cooperate materially\n")
} else if(coop_comparison$summary$correlation > 0.4) {
  cat("Moderate alignment: Verbal and material cooperation partially overlap\n")
} else {
  cat("Weak alignment: Verbal promises don't strongly translate to material actions\n")
}

## ----fig.width=8, fig.height=6------------------------------------------------
# Extract edge change information
edge_changes <- coop_comparison$edge_changes[[1]]

# Create summary of changes
change_summary <- data.frame(
  Type = c("Verbal Only", "Material Only", "Both"),
  Count = c(
    edge_changes$removed,  # In verbal but not material
    edge_changes$added,    # In material but not verbal  
    edge_changes$maintained # In both
  )
)

# Visualize
ggplot(change_summary, aes(x = Type, y = Count)) +
  geom_col(fill = "gray30") +
  labs(title = "Verbal vs Material Cooperation Networks",
       subtitle = "Which relationships exist in each domain?",
       y = "Number of Dyadic Relationships") +
  theme_minimal()

## -----------------------------------------------------------------------------
# Perform QAP test between cooperation and conflict
coop_conf_qap <- compare_networks(
  list(
    cooperation = verb_coop_2002,
    conflict = verb_conf_2002
  ),
  method = "qap",
  n_permutations = 500  # Reduced for vignette speed
)

# Construct message
qap_msg <- paste0(
  "**QAP Test Results:**\n\n",
  "- Observed correlation: ", round(coop_conf_qap$summary$qap_correlation, 3), "\n",
  "- P-value: ", round(coop_conf_qap$summary$qap_pvalue, 3), "\n"
)

# Add interpretation based on significance
if (coop_conf_qap$summary$qap_pvalue < 0.05) {
  if (coop_conf_qap$summary$qap_correlation > 0) {
    qap_msg <- paste0(
      qap_msg,
      "→ Cooperation and conflict networks are positively correlated\n",
      "  (Countries interact through both cooperation AND conflict)\n"
    )
  } else {
    qap_msg <- paste0(
      qap_msg,
      "→ Cooperation and conflict networks are negatively correlated\n",
      "  (Different countries engage in cooperation vs conflict)\n"
    )
  }
} else {
  qap_msg <- paste0(
    qap_msg,
    "→ No significant relationship between cooperation and conflict patterns\n"
  )
}

# Print result
cat(qap_msg)

## -----------------------------------------------------------------------------
# Create networks for multiple years
years_to_compare <- seq(2002, 2014, by=4)

# Create cooperation networks for each year
coop_net_longit <- netify(
  icews[icews$year %in% years_to_compare, ],
  actor1 = 'i', actor2 = 'j',
  time = 'year',
  weight = 'verbCoop',
  symmetric = FALSE,
  output_format = 'longit_list'
)

# Compare across time - automatic pairwise comparisons
temporal_comparison <- compare_networks(
    coop_net_longit, 
    method = "all"
)
# Display temporal comparison results
temporal_comparison

## ----fig.width=10, fig.height=6-----------------------------------------------
# Extract edge changes over time
edge_change_data <- data.frame(
  Comparison = names(temporal_comparison$edge_changes),
  Added = sapply(temporal_comparison$edge_changes, function(x) x$added),
  Removed = sapply(temporal_comparison$edge_changes, function(x) x$removed),
  Maintained = sapply(temporal_comparison$edge_changes, function(x) x$maintained)
)

# Reshape for plotting
edge_change_long <- edge_change_data %>%
  pivot_longer(cols = c(Added, Removed, Maintained), 
               names_to = "Change_Type", 
               values_to = "Count")

# Plot edge changes
ggplot(edge_change_long, aes(x = Comparison, y = Count, fill = Change_Type)) +
  geom_col(position = "dodge") +
  scale_fill_manual(
    values = c(
      "Added" = "#A8D5BA",
      "Removed" = "#E8B4B8",
      "Maintained" = "#95A99C")) +
  labs(
    title = "Edge Changes Between Years",
    subtitle = "Tracking relationship dynamics over time",
    x = "Year Comparison",
    y = "Number of Edges") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(
      angle = 45, hjust = 1)
    )

## -----------------------------------------------------------------------------
# Compare structural properties across years
struct_comparison <- compare_networks(
  coop_net_longit,
  what = "structure"
)

# Display structural comparison
knitr::kable(struct_comparison$summary,
             caption = "Structural Properties Across Time Periods",
             digits = 3,
             align = "c")

## ----fig.width=10, fig.height=8-----------------------------------------------
# Prepare data for visualization
# struct_comparison$summary contains a 
# data.frame with structural metrics over time
struct_data <- struct_comparison$summary

# Calculate percent changes from baseline
baseline_year <- struct_data$network[1]
struct_long <- struct_data %>%
  select(-n_nodes) %>%  # Remove n_nodes since it doesn't change much
  pivot_longer(cols = -network, names_to = "metric", values_to = "value") %>%
  group_by(metric) %>%
  mutate(
    first_value = value[1],
    percent_change = (value - first_value) / first_value * 100
  ) %>%
  ungroup()

# Create heatmap of changes
ggplot(
  filter(struct_long, network != baseline_year), 
  aes(x = network, y = metric, fill = percent_change)) +
  geom_tile(color = "white") +
  geom_text(aes(label = round(percent_change, 1)), color = "black", size = 4) +
  scale_fill_gradient2(
    low = "#d73027", mid = "white", high = "#1a9850", 
    midpoint = 0, name = "% Change") +
  labs(
    title = "Structural Changes Heatmap",
    subtitle = paste("Percent change from", baseline_year),
    x = "", y = "") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 0))

## ----fig.width=10, fig.height=6-----------------------------------------------
# Reshape data for visualization
struct_long <- struct_data %>%
  select(-n_nodes) %>%  # Remove n_nodes since it doesn't change
  pivot_longer(cols = -network, names_to = "metric", values_to = "value") %>%
  group_by(metric) %>%
  mutate(
    # Calculate percent change from first year
    first_value = value[1],
    percent_change = (value - first_value) / first_value * 100,
    # Also calculate year-to-year change
    yoy_change = (value - lag(value)) / lag(value) * 100
  ) %>%
  ungroup()

# Visualize structural changes over time
ggplot(struct_long, aes(x = network, y = value, group = metric)) +
  geom_line(size = 1.2) +
  geom_point(size = 3) +
  facet_wrap(~ metric, scales = "free_y", ncol = 2) +
  labs(
    title = "Structural Properties Over Time",
    subtitle = "Evolution of network characteristics",
    x = "", y = "") +
  theme_minimal() +
  theme(legend.position = "none")

## -----------------------------------------------------------------------------
# Compare node composition
node_comparison <- compare_networks(
  coop_net_longit,
  what = "nodes"
)

# Display node comparison
knitr::kable(node_comparison$summary,
             caption = "Node Composition Across Time Periods", 
             digits = 0,
             align = "c")

## -----------------------------------------------------------------------------
# Compare 2002 and 2014 cooperation networks with full details
early_late_comp <- compare_networks(
  # note subset here is 
  # subset.netify() function
  subset(
    coop_net_longit, 
    time=c("2002", "2014")
    ),
    method = "all",
    return_details = TRUE
)

# Access detailed comparison matrices
names(early_late_comp$details)

# Get edge changes
changes <- early_late_comp$edge_changes[[1]]

# Summary of relationship dynamics
changes_summary <- paste0(
  "**Relationship Dynamics 2002-2014:**\n\n",
  "- Stable relationships: ", changes$maintained, "\n",
  "- New relationships: ", changes$added, "\n", 
  "- Ended relationships: ", changes$removed, "\n",
  "- Total change rate: ", 
  round((changes$added + changes$removed) / 
        (changes$maintained + changes$added + changes$removed) * 100, 1), "%\n"
)

if(!is.na(changes$weight_correlation)) {
  changes_summary <- paste0(changes_summary,
    "- Weight correlation for maintained edges: ", 
    round(changes$weight_correlation, 3), "\n"
  )
  
  if(changes$weight_correlation > 0.7) {
    changes_summary <- paste0(changes_summary, 
      "  → Stable cooperation intensities for continuing relationships\n")
  } else {
    changes_summary <- paste0(changes_summary,
      "  → Cooperation intensities vary even for maintained relationships\n")
  }
}

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(changes_summary)

## -----------------------------------------------------------------------------
# Compare networks using spectral distance
spectral_comp <- compare_networks(
  list(
    "2002" = coop_net_longit[["2002"]],
    "2014" = coop_net_longit[["2014"]]
  ),
  method = "spectral"
)

# Display spectral comparison results
spectral_comp

# Interpretation
# Build spectral interpretation message
spec_dist <- spectral_comp$summary$spectral

spec_msg <- paste0(
  "=== SPECTRAL DISTANCE INTERPRETATION ===\n\n",
  "- Spectral distance: ", round(spec_dist, 2), "\n"
)

# Add interpretation
interpretation <- if (spec_dist < 10) {
  "Low spectral distance: Networks have very similar structural properties\n"
} else if (spec_dist < 50) {
  "Moderate spectral distance: Networks show some structural differences\n"
} else {
  "High spectral distance: Networks have substantially different structures\n"
}

# Combine and print
cat(paste0(spec_msg, "→ ", interpretation))

## -----------------------------------------------------------------------------
# Compare all methods including spectral
full_comp <- compare_networks(
  list(
    early = coop_net_longit[["2002"]],
    late = coop_net_longit[["2014"]]
  ),
  method = "all",
  return_details = TRUE
)

# Extract similarity metrics (0-1 scale) and spectral distance separately
similarity_metrics <- data.frame(
  Method = c("Correlation", "Jaccard", "Hamming"),
  Value = c(
    full_comp$summary$correlation,
    full_comp$summary$jaccard,
    full_comp$summary$hamming
  )
)

spectral_distance <- full_comp$summary$spectral

# Display similarity metrics table
knitr::kable(rbind(similarity_metrics, 
                   data.frame(Method = "Spectral Distance", Value = spectral_distance)),
             caption = "Network Similarity Metrics: 2002 vs 2014",
             digits = 3,
             align = "c")

# Create visualization for similarity metrics
p_similarity <- ggplot(similarity_metrics, aes(x = Method, y = Value)) +
  geom_col(fill = "gray30", width = 0.7) +
  geom_text(aes(label = round(Value, 3)), hjust = -0.1, size = 3.5) +
  scale_y_continuous(limits = c(0, 1.1), breaks = seq(0, 1, 0.2)) +
  labs(title = "Similarity Metrics (0-1 Scale)",
       x = NULL, y = "Similarity Score") +
  theme_minimal() +
  coord_flip()

# Create separate note for spectral distance
spectral_note <- paste("Spectral Distance:", round(spectral_distance, 2))

# Combine the plot with spectral distance information
library(patchwork)
p_similarity + plot_annotation(
  title = "Network Comparison: Multiple Metrics",
  subtitle = paste("2002 vs 2014 Cooperation Networks |", spectral_note),
  theme = theme(plot.title = element_text(face = "bold"))
)

## -----------------------------------------------------------------------------
# Create multilayer network for 2010
icews_2010 <- icews[icews$year == 2010,]

# Create individual networks for each layer
verb_coop_2010 <- netify(
  icews_2010,
  actor1 = 'i', actor2 = 'j',
  weight = 'verbCoop',
  symmetric = FALSE
)

matl_coop_2010 <- netify(
  icews_2010,
  actor1 = 'i', actor2 = 'j',
  weight = 'matlCoop',
  symmetric = FALSE
)

verb_conf_2010 <- netify(
  icews_2010,
  actor1 = 'i', actor2 = 'j',
  weight = 'verbConf',
  symmetric = FALSE
)

matl_conf_2010 <- netify(
  icews_2010,
  actor1 = 'i', actor2 = 'j',
  weight = 'matlConf',
  symmetric = FALSE
)

# Combine into multilayer network
multilayer_2010 <- layer_netify(
  list(
    verbal_coop = verb_coop_2010,
    material_coop = matl_coop_2010,
    verbal_conf = verb_conf_2010,
    material_conf = matl_conf_2010
  )
)

# Compare layers automatically
layer_comparison <- compare_networks(multilayer_2010, method = "all")
# Display multilayer comparison results
layer_comparison

## -----------------------------------------------------------------------------
# Create longitudinal multilayer networks
verb_coop_longit <- netify(
  icews,
  actor1 = 'i', actor2 = 'j',
  time = 'year',
  weight = 'verbCoop',
  symmetric = FALSE,
  output_format = 'longit_array'
)

matl_coop_longit <- netify(
  icews,
  actor1 = 'i', actor2 = 'j',
  time = 'year',
  weight = 'matlCoop',
  symmetric = FALSE,
  output_format = 'longit_array'
)

# Combine into longitudinal multilayer
longit_multilayer <- layer_netify(
  list(
    verbal = verb_coop_longit,
    material = matl_coop_longit
  )
)

# Compare layers across all time periods
longit_layer_comp <- compare_networks(longit_multilayer)

# Display results cleanly
longit_summary <- paste0(
  "**Longitudinal multilayer comparison:**\n\n",
  "- Type: ", longit_layer_comp$comparison_type, "\n",
  "- Number of layers compared: ", longit_layer_comp$n_networks, "\n",
  "- Average correlation between verbal and material cooperation: ", 
  round(mean(longit_layer_comp$summary$correlation), 3), "\n"
)

## ----echo=FALSE, results='asis'-----------------------------------------------
cat(longit_summary)

