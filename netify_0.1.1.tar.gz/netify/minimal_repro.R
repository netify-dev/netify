# Minimal reproducible example

library(netify)

# Create simple test case
data(icews)
icews_10 <- icews[icews$year == 2010, ]
net_10 <- netify(
    icews_10,
    actor1 = "i", actor2 = "j", 
    symmetric = FALSE,
    weight = "verbCoop"
)

# The issue: when using add_text_repel with select_text,
# we get a message about both being TRUE
cat("Issue demonstration:\n")
cat("User provides: add_text_repel=TRUE, select_text=c(...)\n")
cat("Expected: Only repelled text for selected nodes\n")
cat("Actual: Message saying both add_text and add_text_repel are TRUE\n\n")

# Direct test of adjust_plot_args
cat("Direct test of adjust_plot_args:\n")
plot_args <- list(
    add_text_repel = TRUE,
    select_text = c("United States", "China")
)
net_dfs <- netify:::decompose_netify(net_10)
obj_attrs <- attributes(net_10)

result <- netify:::adjust_plot_args(plot_args, net_dfs, obj_attrs)
cat("Result: add_text =", result$plot_args$add_text, 
    ", add_text_repel =", result$plot_args$add_text_repel, "\n")

# Now test the full plot call
cat("\nFull plot call:\n")
plot(net_10,
     add_text_repel = TRUE, 
     select_text = c("United States", "China"))