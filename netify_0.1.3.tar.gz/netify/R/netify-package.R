## usethis namespace: start
#' @useDynLib netify, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom stats cor sd aggregate
## usethis namespace: end
NULL
