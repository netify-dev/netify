## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
    dev = "png", dpi = 150,
    cache = FALSE,
    echo = TRUE
)

## ----eval=TRUE, results='hide', warning=FALSE, message=FALSE------------------
# load packages
library(netify)

# install extra packages for this vignette
if (!"tidyverse" %in% rownames(installed.packages())) {
    install.packages("tidyverse", repos = "https://cloud.r-project.org")
}
if (!"peacesciencer" %in% rownames(installed.packages())) {
    install.packages("peacesciencer", repos = "https://cloud.r-project.org")
}
# load necessary packages for this vignette
library(peacesciencer)
library(tidyverse)

# organize external data for peacesciencer
peacesciencer::download_extdata()

# create dyadic data set over time using peacesciencer
cow_dyads <- create_dyadyears(
    subset_years = c(1995:2014)
) |>
    # add mids
    add_cow_mids() |>
    # add capital distance
    add_capital_distance() |>
    # add democracy
    add_democracy() |>
    # add gdp
    add_sdp_gdp()

## ----eval=TRUE----------------------------------------------------------------
mid_long_network <- netify(
    input = cow_dyads,
    actor1 = "ccode1", actor2 = "ccode2", time = "year",
    weight = "cowmidonset",
    actor_time_uniform = FALSE,
    sum_dyads = FALSE, symmetric = TRUE,
    diag_to_NA = TRUE, missing_to_zero = TRUE,
    nodal_vars = c("v2x_polyarchy1", "v2x_polyarchy2"),
    dyad_vars = c("capdist"),
    dyad_vars_symmetric = c(TRUE)
)

## ----eval=TRUE----------------------------------------------------------------
# create a vector of nodal data
node_data <- unique(cow_dyads[, c("ccode1", "year", "wbgdppc2011est2")])
node_data$wbgdppc2011est2_log <- log(node_data$wbgdppc2011est2)

# add nodal variable to netlet object
mid_long_network <- add_node_vars(
    netlet = mid_long_network,
    node_data = node_data,
    actor = "ccode1",
    time = "year"
)

# create another dyadic var in cow
cow_dyads$log_capdist <- log(cow_dyads$capdist + 1)

# now lets add this to the netlet
mid_long_network <- add_dyad_vars(
    netlet = mid_long_network,
    dyad_data = cow_dyads,
    actor1 = "ccode1",
    actor2 = "ccode2",
    time = "year",
    dyad_vars = "log_capdist",
    dyad_vars_symmetric = TRUE
)

## -----------------------------------------------------------------------------
peek(mid_long_network,
    from = 5, to = 5,
    time = c("2009", "2010")
)

## -----------------------------------------------------------------------------
# create data.frame that provides network-level summary stats
# for each year of the network
mid_long_summary <- summary(mid_long_network)

## ----fig.width=6, fig.height=6------------------------------------------------
plot_graph_stats(mid_long_summary)

## -----------------------------------------------------------------------------
# every year & every actor
summary_actor_mids <- summary_actor(mid_long_network)
head(summary_actor_mids)

## ----fig.width=6, fig.height=6, warning = FALSE, message = FALSE--------------
# density plot across all actors
# for each stat
plot_actor_stats(
    summary_actor_mids,
    across_actor = TRUE,
)

## ----fig.width=6, fig.height=6------------------------------------------------
# focus on closeness
plot_actor_stats(
    summary_actor_mids,
    across_actor = TRUE,
    specific_stats = "closeness"
)

## ----fig.width=6, fig.height=6------------------------------------------------
# top 5 GDP countries (USA, China, Japan, Germany, India)
top_5 <- c("2", "710", "740", "255", "750")

#
plot_actor_stats(
    summary_actor_mids,
    across_actor = FALSE,
    specific_actors = top_5
)

## ----fig.width=6, fig.height=6------------------------------------------------
summary_df_static <- summary_actor_mids[summary_actor_mids$time == 2011, ]

plot_actor_stats(
    summary_df_static,
    across_actor = FALSE,
    specific_actors = top_5
)

## ----fig.width=6, fig.height=6------------------------------------------------
# default plot
plot.netify(mid_long_network,
    static_actor_positions = TRUE,
    remove_isolates = FALSE
)

# a little cleaner
plot(
    mid_long_network,
    edge_color = "grey",
    node_size = 2
)

## -----------------------------------------------------------------------------
# add actor variables from summary_actor_mids
mid_long_network <- add_node_vars(
    mid_long_network,
    summary_actor_mids,
    actor = "actor", time = "time",
    node_vars = c("degree", "prop_ties", "eigen_vector"),
)

## -----------------------------------------------------------------------------
# print netlet obj to make sure they got added to nodal features
print(mid_long_network)

## -----------------------------------------------------------------------------
# if you're curious as to where they live
head(
    attr(
        mid_long_network,
        "nodal_data"
    )
)

# i.e.,
head(attributes(mid_long_network)$nodal_data)

## ----fig.width=6, fig.height=6------------------------------------------------
# vary node size by degree
plot(
    mid_long_network,
    edge_color = "grey",
    point_size_var = "degree"
)

# vary node color by polyarchy
plot(
    mid_long_network,
    edge_color = "grey",
    node_size_by = "degree",
    node_color_by = "v2x_polyarchy1",
    node_color_label = "Polyarchy",
    node_size_label = "Degree"
) +
    scale_color_gradient2()

## ----fig.width=6, fig.height=6------------------------------------------------
library(countrycode)
cowns <- countrycode(
    c(
        "United States", "China", "Russia",
        "France", "Germany", "United Kingdom"
    ),
    "country.name", "cown"
)
cabbs <- countrycode(cowns, "cown", "iso3c")

plot(
    mid_long_network,
    edge_color = "grey",
    node_size_by = "degree",
    node_color_by = "v2x_polyarchy1",
    node_color_label = "Polyarchy",
    node_size_label = "Degree",
    select_text = cowns,
    select_text_display = cabbs,
    text_size = 3
) +
    scale_color_gradient2()

# or we can go with labels only
# and remove points
plot(
    mid_long_network,
    edge_color = "grey",
    add_points = FALSE,
    add_label = TRUE,
    label_size_by = "degree",
    label_color = "white",
    label_fill_by = "v2x_polyarchy1",
    label_fill_label = "Polyarchy",
    label_size_label = "Degree"
) + guides(size = "none")

## ----warning=FALSE, message = FALSE-------------------------------------------
# prep data
cow_cross <- cow_dyads |>
    group_by(ccode1, ccode2) |>
    summarize(
        cowmidonset = ifelse(any(cowmidonset > 0), 1, 0),
        capdist = mean(capdist),
        polity21 = mean(polity21, na.rm = TRUE),
        polity22 = mean(polity22, na.rm = TRUE),
        wbgdp2011est1 = mean(wbgdp2011est1, na.rm = TRUE),
        wbgdp2011est2 = mean(wbgdp2011est2, na.rm = TRUE),
        wbpopest1 = mean(wbpopest1, na.rm = TRUE),
        wbpopest2 = mean(wbpopest2, na.rm = TRUE)
    ) |>
    ungroup() |>
    mutate(
        capdist = log(capdist + 1)
    )

# subset set to actors with 10mil pop
actor_to_keep <- cow_cross |>
    select(ccode1, wbpopest1) |>
    filter(wbpopest1 > log(10000000)) |>
    distinct(ccode1)

# filter cow_cross by actor_to_keep
cow_cross <- cow_cross |>
    filter(ccode1 %in% actor_to_keep$ccode1) |>
    filter(ccode2 %in% actor_to_keep$ccode1)

# create netlet
mid_cross_network <- netify(
    cow_cross,
    actor1 = "ccode1", actor2 = "ccode2",
    weight = "cowmidonset",
    sum_dyads = FALSE, symmetric = TRUE,
    diag_to_NA = TRUE, missing_to_zero = FALSE,
    nodal_vars = c(
        "polity21", "polity22", "wbgdp2011est1",
        "wbgdp2011est2", "wbpopest1", "wbpopest2"
    ),
    dyad_vars = c("capdist"),
    dyad_vars_symmetric = c(TRUE)
)

## -----------------------------------------------------------------------------
# install (if necessary) and load amen
if (!"amen" %in% rownames(installed.packages())) {
    install.packages("amen", repos = "https://cloud.r-project.org")
}
library(amen)

# prep for amen
mid_cross_amen <- netify_to_amen(mid_cross_network)

# we got all the elements we need for amen! woohoO!
str(mid_cross_amen)

# plug and run
mid_amen_mod <- ame(
    Y = mid_cross_amen$Y,
    Xdyad = mid_cross_amen$Xdyad,
    Xrow = mid_cross_amen$Xrow,
    family = "bin",
    R = 0,
    symmetric = TRUE,
    seed = 6886,
    nscan = 50,
    burn = 10,
    odens = 1,
    plot = FALSE,
    print = FALSE
)

## -----------------------------------------------------------------------------
# install (if necessary) and load ergm
if (!"ergm" %in% rownames(installed.packages())) {
    install.packages("ergm", repos = "https://cloud.r-project.org")
}
library(ergm)

# called netify_to_statnet because it's a reference
# to the network library, which is what ergm uses
mid_cross_ergm <- netify_to_statnet(mid_cross_network)

# attributes should all be loaded into the
# appropriate slot
# notice edge attribtues get a _e suffix added
mid_cross_ergm

# set NA values to 0 for the three nodecov variables
# this is only for demonstration purposes in the vignette/example
# in any real analysis, carefully consider how to handle missing data
set.vertex.attribute(
    mid_cross_ergm, "polity21", 
    ifelse(
        is.na(get.vertex.attribute(mid_cross_ergm, "polity21")), 
        0, get.vertex.attribute(mid_cross_ergm, "polity21")))

set.vertex.attribute(
    mid_cross_ergm, "wbgdp2011est2", 
    ifelse(
        is.na(get.vertex.attribute(mid_cross_ergm, "wbgdp2011est2")), 
        0, get.vertex.attribute(mid_cross_ergm, "wbgdp2011est2")) )

set.vertex.attribute(
    mid_cross_ergm, "wbpopest2", 
    ifelse(
        is.na(get.vertex.attribute(mid_cross_ergm, "wbpopest2")), 
        0,  get.vertex.attribute(mid_cross_ergm, "wbpopest2")) )

# plug and run
# Fit the ERGM model (well not a real ergm)
ergm_model <- ergm(
    formula = mid_cross_ergm ~
        edges +
        nodecov("polity21") +
        nodecov("wbgdp2011est2") +
        nodecov("wbpopest2")
)

