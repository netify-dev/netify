library(testthat)
library(netify)

test_check("netify")
