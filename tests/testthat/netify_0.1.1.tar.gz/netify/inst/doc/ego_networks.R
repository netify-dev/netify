## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(netify)

## -----------------------------------------------------------------------------
# load icews data
data(icews)

# choose attributes
nvars = c( 'i_polity2', 'i_log_gdp', 'i_log_pop' )
dvars = c( 'matlCoop', 'verbConf', 'matlConf' )

# create a netify object
netlet = netify(
    icews, 
    actor1='i', actor2='j',
    time = 'year',
    symmetric=FALSE, weight='verbCoop',
    mode='unipartite', sum_dyads=FALSE,
    actor_time_uniform=TRUE, actor_pds=NULL,
    diag_to_NA=TRUE, missing_to_zero=TRUE,
    nodal_vars = nvars, 
    dyad_vars = dvars
)

# print
netlet

## -----------------------------------------------------------------------------
# extract ego network for Pakistan
pakistan_ego_net = ego_netify(netlet, ego = 'Pakistan')

# print
pakistan_ego_net

## -----------------------------------------------------------------------------
# subset to a specific year
subset(pakistan_ego_net, time = '2010')

## -----------------------------------------------------------------------------
head(summary(pakistan_ego_net))

## -----------------------------------------------------------------------------
pakistan_ego_net = add_node_vars(
  pakistan_ego_net, 
  summary_actor(pakistan_ego_net), 
  'actor', 'time'
)

plot(pakistan_ego_net,
     edge_color = 'grey50',
     weight_transform=log1p,
     node_size_by = 'log(strength_avg_total)',
     node_size_label = 'Log(Strength)',
     edge_alpha_label = 'Log(Verb. Coop.)',
     highlight='Pakistan',
     highlight_legend_title='',
     edge_linewidth = .2
)

