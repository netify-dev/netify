## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  dev = 'png', dpi = 150,
  cache = FALSE,
  echo = TRUE
)

## -----------------------------------------------------------------------------
library(netify)
library(ggplot2)

## -----------------------------------------------------------------------------
# Load UCDP GED data on Mexico
data(mexico)

# Construct unweighted network (number_of_events by default)
mex_network <- netify(
  mexico,
  actor1 = 'side_a',
  actor2 = 'side_b',
  symmetric = TRUE,
  sum_dyads = TRUE,
  diag_to_NA = TRUE,
  missing_to_zero = TRUE
)

# Summaries at the graph and actor levels
summary(mex_network)

actor_stats <- summary_actor(mex_network)
plot_actor_stats(actor_stats)

## ----fig.width=6, fig.height=6------------------------------------------------
# select 10 random names for plotting
select_names <- rownames(mex_network)
set.seed(6886)
random_indices <- sample(length(select_names), 10)
random_names <- select_names[random_indices]

plot(mex_network,
  add_text = TRUE)
    
plot(mex_network,
  select_text = random_names,
  select_text_display = random_names)

## ----fig.width=6, fig.height=6------------------------------------------------
plot(mex_network,
  select_text = random_names,
  select_text_display = random_names, 
  # log(x+1) to better see range of connects
  weight_transform = log1p
  )

## ----fig.width=6, fig.height=6------------------------------------------------
# investigate each component of the plot
comp <- plot(
  mex_network,
  remove_isolates = TRUE,
  select_text = random_names,
  select_text_display = random_names,              
  weight_transform = log1p,
  return_components = TRUE
  )

print(comp)

# modify component
comp$base + 
  netify_edge(comp) + 
  labs(alpha='Log(Event Count)') +
  reset_scales() +
  netify_node(comp) +
  netify_text(comp) +
  comp$theme

## ----fig.width=6, fig.height=6------------------------------------------------
# and even simpler
plot(mex_network, 
  select_text = random_names,
  select_text_display = random_names,
  weight_transform = log1p,
  edge_alpha_label = "Log(Event Count)")

## ----fig.width=6, fig.height=6------------------------------------------------
# add degree centrality 
mex_network = add_node_vars(
  mex_network, 
  summary_actor(mex_network), 
  actor='actor' )

plot(mex_network, 
  weight_transform = log1p,
  edge_alpha_label = "Log(Event Count)",
  point_size_by='degree',
  point_size_label='Degree',
  point_alpha=.5,
  check_overlap=TRUE
    )

