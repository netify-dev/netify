# Test script to measure speedup from C++ implementation
library(netify)
library(microbenchmark)

# Load example data
data(icews)

# Create test networks
years_to_compare <- seq(2002, 2014, by=4)

# Create cooperation networks for each year
coop_net_longit <- netify(
  icews[icews$year %in% years_to_compare, ],
  actor1 = 'i', actor2 = 'j',
  time = 'year',
  weight = 'verbCoop',
  symmetric = FALSE,
  output_format = 'longit_list'
)

# Test the speed
cat("Testing compare_networks speed with C++ optimizations...\n")

# Warm up
invisible(compare_networks(coop_net_longit, method = "all"))

# Benchmark
bench_results <- microbenchmark(
  correlation = compare_networks(coop_net_longit, method = "correlation"),
  jaccard = compare_networks(coop_net_longit, method = "jaccard"),
  hamming = compare_networks(coop_net_longit, method = "hamming"),
  qap = compare_networks(coop_net_longit, method = "qap", n_permutations = 100),
  spectral = compare_networks(coop_net_longit, method = "spectral"),
  all = compare_networks(coop_net_longit, method = "all", n_permutations = 100),
  times = 10
)

print(bench_results)

# Summary
cat("\n\nSummary:\n")
cat("The C++ implementations should provide significant speedup, especially for:\n")
cat("- QAP permutation tests (most improvement expected)\n")
cat("- Spectral distance calculations (eigenvalue computations)\n")
cat("- Edge change calculations (avoiding R loops)\n")
cat("- Jaccard/Hamming calculations (vectorized operations)\n")